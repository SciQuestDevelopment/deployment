## Server of SciQuest 

此项目旨在开发用于SciQuest的服务器.

* 如果需要安装服务器, 请访问[安装和运行文档](docs/install.md). 
* 如果需要查询APIs, 请访问[APIs接口文档](docs/apis.md). 

